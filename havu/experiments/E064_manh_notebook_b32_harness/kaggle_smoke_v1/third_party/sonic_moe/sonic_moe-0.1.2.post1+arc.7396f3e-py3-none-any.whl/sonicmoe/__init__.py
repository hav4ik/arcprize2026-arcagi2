# ********************************************************************************
# Copyright (c) 2025, Wentao Guo, Mayank Mishra, Xinle Cheng, Ion Stoica, Tri Dao
# ********************************************************************************

__version__ = "0.1.2.post1+arc.7396f3e"

from .enums import KernelBackendMoE
from .functional import moe_general_routing_inputs, moe_TC_softmax_topk_layer
from .moe import MoE

# Added only by the ARC packaging step; kernel source is unchanged.
__arc_upstream_commit__ = "7396f3e604827d8186c2e16e64b28ee33d3defd0"
__arc_pack_schema__ = 1
